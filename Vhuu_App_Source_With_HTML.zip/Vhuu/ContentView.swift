import SwiftUI
import WebKit

@main
struct VhuuApp: App {
    var body: some Scene {
        WindowGroup {
            BundledHTMLView()
                .ignoresSafeArea()
                .preferredColorScheme(.dark)
        }
    }
}

struct BundledHTMLView: UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 5/255, green: 10/255, blue: 18/255, alpha: 1)
        webView.scrollView.backgroundColor = webView.backgroundColor
        if let fileURL = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(fileURL, allowingReadAccessTo: fileURL.deletingLastPathComponent())
        } else {
            let fallback = "<html><body style='background:#050a12;color:#00eaff;font-family:-apple-system;padding:24px'>Không tìm thấy index.html trong ứng dụng.</body></html>"
            webView.loadHTMLString(fallback, baseURL: nil)
        }
        return webView
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
