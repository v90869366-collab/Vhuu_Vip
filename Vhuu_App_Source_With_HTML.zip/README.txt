Vhuu iOS source project

The app loads the bundled index.html locally with WKWebView. It does not require a web server to display the HTML.

To use the HTML on GitHub Pages, upload VhuuVip_index_updated.html renamed to index.html into the root of the Pages repository, then enable GitHub Pages in repository Settings > Pages.

The key check and toggles are UI demo behavior only; they do not control iOS settings or game internals.
