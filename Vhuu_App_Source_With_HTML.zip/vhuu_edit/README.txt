Vhuu iOS app source (updated UI)

Changes:
- Tightened the Vhuu wordmark spacing on both the key-entry screen and dashboard.
- When a feature toggle is turned on, an alert confirms “Feature name đã kích hoạt ✅”.
- When a feature toggle is turned off, an alert confirms “Feature name đã tắt ❌”.

Key: VhuuVip

This is a SwiftUI source project intended to be opened in Xcode on a Mac. The feature toggles are UI demo states and do not directly modify game internals or iOS settings.
